Developer's Guide
========
 * [Build from source tree](build.md)
 * [Debug on IntelliJ](debug.md)
 * [Directory Structure](directory.md)
 * [Mapping and Validation](validation.md)
 * [Authentication in Controller](authenticator.md)
 * [About Action in Issue Comment](comment_action.md)
 * [Activity Types](activity.md)
 * [Automatic Schema Updating](auto_update.md)
 * [Release Operation](release.md)
 * [Licenses](licenses.md)
