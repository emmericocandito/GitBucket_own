# Contrib Notes #

The configuration script adapts according to the OS.
The `linux` directory contains scripts for Ubuntu and RedHat.
The Mac scripts have been folded in as well.
Common scripts are in this directory.

This version of scripts has so far only been tested on Ubuntu and Mac. Someone else will have to test on RedHat.

To run:

  1. Edit `gitbucket.conf` to suit.
  2. Type: `install`
