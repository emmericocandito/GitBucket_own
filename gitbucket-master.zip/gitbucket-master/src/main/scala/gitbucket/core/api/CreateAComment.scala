package gitbucket.core.api

/**
 * https://developer.github.com/v3/issues/comments/#create-a-comment
 * api form
 */
case class CreateAComment(body: String)
