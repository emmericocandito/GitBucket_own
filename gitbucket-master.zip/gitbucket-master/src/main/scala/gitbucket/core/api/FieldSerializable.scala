package gitbucket.core.api

/** export fields for json */
trait FieldSerializable
